
const config = requireDir( './config' );

module.exports = {
	purge: {
		enabled: true,
		content: ['./dev/components/index.html'],
	},
	theme: {},
	variants: {},
	plugins: [],
}
