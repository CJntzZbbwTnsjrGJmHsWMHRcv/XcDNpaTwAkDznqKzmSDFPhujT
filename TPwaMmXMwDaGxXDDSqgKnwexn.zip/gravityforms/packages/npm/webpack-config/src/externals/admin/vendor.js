const vendor = {
	'jquery': 'jQuery',
};

module.exports = vendor;
