/**
 * @function bindEvents
 * @description Bind global event listeners here,
 */

const bindEvents = () => {};

const init = () => {
	bindEvents();

	console.info(
		'Gravity Forms Common: Initialized all javascript that targeted document ready.'
	);
};

export default init;
