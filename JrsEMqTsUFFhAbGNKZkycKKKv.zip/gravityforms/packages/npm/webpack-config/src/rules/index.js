const scripts = require( './scripts' );

module.exports = [
	scripts,
];
